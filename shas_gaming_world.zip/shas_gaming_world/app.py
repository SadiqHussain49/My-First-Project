from flask import Flask, render_template, request, jsonify
from datetime import datetime
from pathlib import Path
import sqlite3
import re

app = Flask(__name__)
DB = Path(__file__).with_name('enquiries.db')

PRODUCT = {
    'name': 'PlayStation 5',
    'price': 59000,
    'currency': 'INR',
    'description': 'Experience next-generation gaming with PlayStation 5.',
}


def init_db():
    with sqlite3.connect(DB) as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS enquiries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            message TEXT,
            product TEXT NOT NULL,
            created_at TEXT NOT NULL
        )''')


@app.route('/')
def home():
    return render_template('index.html', product=PRODUCT)


@app.post('/enquire')
def enquire():
    data = request.get_json(silent=True) if request.is_json else request.form
    data = data or {}
    name = str(data.get('name', '')).strip()
    email = str(data.get('email', '')).strip()
    phone = str(data.get('phone', '')).strip()
    message = str(data.get('message', '')).strip()

    if not all((name, email, phone)):
        return jsonify({'success': False, 'message': 'Please fill in your name, email and phone number.'}), 400
    if len(name) > 100 or len(message) > 1000 or len(phone) > 25 or len(email) > 254:
        return jsonify({'success': False, 'message': 'One or more fields are too long.'}), 400
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
        return jsonify({'success': False, 'message': 'Please enter a valid email address.'}), 400
    if not re.fullmatch(r'[+\d\s()\-]{7,25}', phone):
        return jsonify({'success': False, 'message': 'Please enter a valid phone number.'}), 400

    with sqlite3.connect(DB) as conn:
        conn.execute(
            'INSERT INTO enquiries (name,email,phone,message,product,created_at) VALUES (?,?,?,?,?,?)',
            (name, email, phone, message, PRODUCT['name'], datetime.now().isoformat(timespec='seconds'))
        )
    return jsonify({'success': True, 'message': 'Thanks! Your enquiry has been received. We will contact you soon.'})


if __name__ == '__main__':
    init_db()
    app.run(debug=True)
else:
    init_db()
