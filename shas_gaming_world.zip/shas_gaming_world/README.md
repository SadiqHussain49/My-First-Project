# Shas Gaming World 🎮

A responsive PS5 storefront built with **Python + Flask**, featuring a PlayStation 5 priced at **₹59,000** and a working enquiry form.

## How to run (Windows, macOS, or Linux)

1. Install Python 3.10 or newer from https://python.org/.
2. Open a terminal in this folder.
3. Run:

```bash
python -m pip install -r requirements.txt
python app.py
```

4. Open **http://127.0.0.1:5000/** in your browser.

If `python` does not work on Windows, try `py` instead.

## Files

- `app.py` — Flask routes, product price, and enquiry database.
- `templates/index.html` — website content.
- `static/style.css` — gaming-themed design.
- `static/script.js` — interactive enquiry form.
- `enquiries.db` — created automatically when you run the app; stores customer enquiries locally.

## Important before going live

- This is an **enquiry-based storefront**, **not** a payment-enabled ecommerce store. No payments are collected.
- You can update the product price by editing `PRODUCT['price']` in `app.py`.
- Confirm the **PS5 edition, condition, availability, warranty, shipping, returns, seller identity and contact information** before accepting orders.
- The PS5 illustration is made with CSS, not an official Sony image.
- For a public production website, disable Flask debug mode, use a production WSGI server, add spam protection, and implement appropriate privacy/data retention safeguards for stored enquiries.
