document.getElementById('year').textContent = new Date().getFullYear();
const form = document.getElementById('enquiryForm');
const status = document.getElementById('formStatus');
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = form.querySelector('button[type="submit"]');
  status.textContent = 'Sending your enquiry…';
  status.className = '';
  button.disabled = true;
  try {
    const response = await fetch('/enquire', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(Object.fromEntries(new FormData(form).entries()))
    });
    const data = await response.json();
    status.textContent = data.message || 'Something went wrong. Please try again.';
    status.className = response.ok && data.success ? 'success' : 'error';
    if (response.ok && data.success) form.reset();
  } catch (error) {
    status.textContent = 'Could not send your enquiry. Please try again.';
    status.className = 'error';
  } finally { button.disabled = false; }
});
